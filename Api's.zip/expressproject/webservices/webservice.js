 //1. Loas express 
 var express = require('express');
 //1a. load the 'path' module. Ths will be used by static middleware of express.
 //The path is the standard node module
 var path = require('path');
 //1b. import the data module 
 //var userModel =  require('./usermodel');
 //1c. load the body parser
 var bodyParser =  require('body-parser');
 //1d. loading mongoose driver
 var mongoose = require("mongoose");
 
 //1e. set the global promise to manage all asyncalls made by appl using mongoose driver
 mongoose.Promise = global.Promise;
 //2. define an instance of express
 var instance = express();
 //2a. load cors
 var cors = require("cors");
 
 var jwt = require("jsonwebtoken");
 
//  var personModel = require("./../Models/personModel");
 
//  var loginModel = require("./../Models/loginModel");
 
 // var usrModel = require("./../Models/usermodel");
 
 var rolesSchema = mongoose.Schema({
     RoleId:Number,
     RoleName:String
        
     });
     //5c. Map the schema with the collection
                                     //    name    schema        collection
     var rolesModel = mongoose.model("Roles",rolesSchema,"Roles");
 
 
 
 //3. configure all middlewares 
 //3a. static files
 //use is used for configuring middleware or adding them on express instance
 instance.use(express.static(path.join(__dirname,'./../node_modules/jquery/dist')
 )
 );
 //3. define express - router , for saggregating urls for html page and rest api requests
 var router = express.Router();
 
 //3c. add the router object in the express middleware 
 instance.use(router);
 
 //3d. configure the body parser middleware
 //3d.1 use urlencoded as false to read data from http url as querystring/formmodel etc.
 instance.use(bodyParser.urlencoded({extended:false}));
 
 //3d.2 use the json() parser for body parser
 instance.use(bodyParser.json());
 //3e. configure cors
 instance.use(cors({}))
 
 //4. create web request handlers 
 //4a. this will return the home.html from views folder
 router.get("/home",function(req,resp){
     resp.sendFile("home.html",{
         root: path.join(__dirname,"./../views")
     });
 });
 //5. Model-schema mapping with collection on mongo db 
 //and establishing connection with it
 mongoose.connect("mongodb://localhost/PersonInformation",
 {
     useNewUrlParser:true
 });
 //5a. get the connection object
 //if db connect is not undefined then the connection is successful
 var dbConnect = mongoose.connection;
 if(!dbConnect){
     console.log("SOrry connection has not been set");
     return;
 }
 //5b define schema (recommended to have same aatibutes as per the collection)
 var userSchema = mongoose.Schema({
 UserId:Number,
 UserName:String,
 EmailId:String,
 Password:String,
 RoleId:Number
    
 });

 //5c. Map the schema with the collection
                                 //    name    schema        collection
 var userModel = mongoose.model("users",userSchema,"users");
 
 // var personModel = mongoose.model("Person",personSchema,"Person");
 
 // var loginModel = mongoose.model("LoginStatus",loginSchema,"LoginStatus");
 
 instance.post("/api/userData", function(request, response) {
    // parsing posted data into JSON
    console.log("in api service");
    var usrData = {
        UserId: request.body.UserId,
      UserName: request.body.UserName,
      EmailId: request.body.EmailId,
      Password: request.body.Password,
      RoleId: request.body.RoleId
      
    };
    console.log("RoleId is ===="+request.body.RoleId);
    // pass the parsed object to "create()" method
    userModel.create(usrData, function(err, res) {
      if (err) {
        console.log("Some error occured ");
        throw error;
      }
      response.send({ status: 200, data: res });
    });
  });

  instance.get("/api/getUserDetails", function(request, response) {
    // parsing posted data into JSON
   
    userModel.find(function(err,res){
     
      if (err) {
        console.log("Some error occured ");
        throw error;
      }
      response.send({ status: 200, data: res });
    });
  });
 
 
 var jwtSettings = {
    jwtSecret: "dbcsbiobc0708hdfcyesbombob"
   };
   // set the secret with express object
   instance.set("jwtSecret", jwtSettings.jwtSecret);
   var tokenStore = "";
    
 
    
 instance.post("/api/signin",function(request,response){
     var user = {
         UserName: request.body.UserName,
         Password: request.body.Password
         };
         console.log("In Auth User " + JSON.stringify(user));
         userModel.findOne({ UserName: request.body.UserName }, function(err, usr) {
         if (err) {
         console.log("Some error occured ");
         throw error;
         }
         // 7a. if user not found the respond error
         if (!usr) {
         response.send({
         statusCode: 404,
         message: "Sorry!User is not available"
         });
         } else if (usr) {
         // 7b. user is available but password not match the
         // respond error
         console.log("In else if " + JSON.stringify(usr));
          userModel.findOne({ Password: request.body.Password }, function(err, res) {
             if (err) {
                 console.log("Some error occured ");
                 throw error;
                 }
                 // 7a. if user not found the respond error
                 if (!res.Password) {
                 response.send({
                 statusCode: 404,
                 message: "Sorry!Password is incorrect"
                 });
                 } else if (res.Password) {
          // 7c. sing-In the user and generate token
         var token = jwt.sign({ usr }, instance.get("jwtSecret"), {
         expiresIn: 3600
         });
         
 
         tokenStore = token;
         //console.log("loginresp", loginresp);
          console.log(JSON.stringify(res));
         response.send({
         authenticated: true,
         message: "Login Success",
         token: token,
         data:res.RoleId
                 
         //logindetails:loginresp
         
         // data:JSON.stringify(result)
                 });
                // loginModel.createLoginDetails(request,response);
 
                 // loginModel.createLoginDetails(request,response);
 
                   //console.log(JSON.stringify(logresult));
          }
         
         });
       //  loginModel.createLoginDetails(request,response);
      }
     });
     });
 
     var jwtSettings = {
      jwtSecret: "dbcsbiobc0708hdfcyesbombob"
     };
     // set the secret with express object
     instance.set("jwtSecret", jwtSettings.jwtSecret);
     var tokenStore = "";


     instance.post("/api/createRoles", function (request, response) {
        
      personModel.getPersonFromTemp(request,response)
              
         
      });

    
 
 //6. start listening 
 instance.listen(4070,function(){
     console.log("start listening on port 4070");
 });
 