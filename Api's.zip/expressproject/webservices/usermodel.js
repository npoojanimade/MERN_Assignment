var mongoose = require("mongoose");
//1e. set the global promise to manage all asyncalls made by appl using mongoose driver
mongoose.Promise = global.Promise;


const AutoIncrement = require('mongoose-sequence')(mongoose);
  
var userSchema = mongoose.Schema({
    UserId:Number,
    UserName:String,
    EmailId:String,
    Password:String,
    RoleId:Number
       
    });

    userSchema.plugin(AutoIncrement, {inc_field: 'UserId'});

  var userModel = mongoose.model("users",userSchema,"users");

  
module.exports={
    createUser:function(request,response){
        user={
            UserName:request.body.UserName,
            EmailId:request.body.EmailId,
            Password:request.body.Password,
            RoleId:request.body.RoleId
        }
        userModel.create(user,function(err,res){
    //6b. if error occurred the response error
    if(err){
        response.statusCode = 500;
        response.send({status: response.statusCode,error:err});
        return;
    }
    response.send({status:200,data:res});

     });
    },

    getUserDetails:function(request,response){
        userModel.find.exec(function(err,res){
          
            if(err){
                response.statusCode = 500;
                response.send({status: response.statusCode,error:err});
                
            }
            response.send({status:200,data:res});
        }) ;   
        }

   }


