var mongoose = require("mongoose");
//1e. set the global promise to manage all asyncalls made by appl using mongoose driver
mongoose.Promise = global.Promise;

const AutoIncrement = require('mongoose-sequence')(mongoose);


var personSchema = mongoose.Schema({
    AdharNo:Number,
    PersonUniqueId:Number,
    Gender:String,
    DOB:Date,
    Age:Number,
    FirstName:String,
    MiddleName:String,
    LastName:String,
    // Address:{
        FlatNo:Number,
        SocietyName:String,
        StreetName:String,
    // },
    City:String,
    State:String,
    Pincode:Number,
    PhoneNo:Number,
    MobileNo:Number,
    PhysicalDisabilityIfAny:String,
    MaritalStatus:String,
    EducationStatus:String,
    BirthSign:String,

});

var tempSchema = mongoose.Schema({
    AdharNo:Number,
   
    Gender:String,
    DOB:Date,
    Age:Number,
    FirstName:String,
    MiddleName:String,
    LastName:String,
    // Address:{
        FlatNo:Number,
        SocietyName:String,
        StreetName:String,
    // },
    City:String,
    State:String,
    Pincode:Number,
    PhoneNo:Number,
    MobileNo:Number,
    PhysicalDisabilityIfAny:String,
    MaritalStatus:String,
    EducationStatus:String,
    BirthSign:String,

});

personSchema.plugin(AutoIncrement, {inc_field: 'PersonUniqueId'});
var personModel = mongoose.model("Person",personSchema,"Person");



var tempModel = mongoose.model("PersonTemp",tempSchema,"PersonTemp");


//    name    schema        collection
//  var usrModel = mongoose.model("UserModel",userSchema,"UserModel");

module.exports={
    approveUser:function(request,response){
       var person={
        AdharNo:request.body.AdharNo,
        //PersonUniqueId:request.body.PersonUniqueId,
        Gender:request.body.Gender,
        DateOfBirth:request.body.DateOfBirth,
        Age:request.body.Age,
        FirstName:request.body.FirstName,
        MiddleName:request.body.MiddleName,
        LastName:request.body.LastName,
        // Address:{
            FlatNo:request.body.FlatNo,
            SocietyName:request.body.SocietyName,
            StreetName:request.body.StreetName,
        // },
        City:request.body.City,
        State:request.body.State,
        Pincode:request.body.Pincode,
        PhoneNo:request.body.PhoneNo,
        MobileNo:request.body.MobileNo,
        PhysicalDisabilityIfAny:request.body.PhysicalDisabilityIfAny,
        MaritalStatus:request.body.MaritalStatus,
        EducationStatus:request.body.EducationStatus,
        BirthSign:request.body.BirthSign
       }
                                    
                                      
       personModel.create(person, function (err, res)  {
                        console.log("-------", person);
                        console.log();

                        console.log("while approving person : ", JSON.stringify(res));
                        if (err) {
                            response.statusCode = 500;
                            response.send({ status: response.statusCode, error: err,
                            message:"Error occurred while creating person" });
                            return;
                        }

                        response.send({ status: 200, data: res });
                    });
           
    },
    

getPerson:function(request,response){
    console.log("Indise gePerson")
 var id = request.body.AdharNo;
 console.log(id);
 tempModel.findOne({id},function(err,res){
         
   if (err) {
    console.log("Indise err")

     response.statusCode = 500;
     response.send(err.message);
   }
   //response.send({ status: 200, data: res });
   if(!res){
    console.log("Indise not res")

    response.send({
        statusCode: 404,
        message: "Sorry!Person is not available with the provided adhar no"
});
   }
  else if(res){
    console.log("Indise response")

      console.log(JSON.stringify(res));
      response.send({
        statusCode: 200,
        message: "Person Present"
      });
   
    }
 });
   

},

getPersonFromTemp:function(request,response){
    console.log("Indise gePerson")
 
 tempModel.find.exec(function(err,res){
         
   if (err) {
    console.log("Indise err")

     response.statusCode = 500;
     response.send(err.message);
   }
   //response.send({ status: 200, data: res });
   if(!res){
    console.log("Indise not res")

    response.send({
        statusCode: 404,
        message: "Sorry!Person List not available"
});
   }
  else if(res){
    console.log("Indise response")

      console.log(JSON.stringify(res));
      response.send({
        statusCode: 200,
        message: "Person Present"
      });
   
    }
 });
   

},

getPersonFromPersonWithId:function(request,response){
    var id = request.body.PersonUniqueId;
    console.log("Indise gePerson")
 
 tempModel.findOne({id},function(err,res){
         
   if (err) {
    console.log("Indise err")

     response.statusCode = 500;
     response.send(err.message);
   }
   //response.send({ status: 200, data: res });
   if(!res){
    console.log("Indise not res")

    response.send({
        statusCode: 404,
        message: "Sorry!Person not available with provided id"
});
   }
  else if(res){
    console.log("Indise response")

      console.log(JSON.stringify(res));
      response.send({
        statusCode: 200,
        message: "Person Present"
      });
   
    }
 });
   

},

// updatePerson:function(id){
//     var person = mongoose.Schema({
//         AdharNo:request.body.AdharNo,
//         PersonUniqueId:request.body.PersonUniqueId,
//         Gender:request.body.Gender,
//         DateOfBirth:request.body.DateOfBirth,
//         Age:request.body.Age,
//         Address:{
//             FlatNo:request.body.FlatNo,
//             SocietyName:request.body.SocietyName,
//             StreetName:request.body.StreetName
//         },
//         City:request.body.City,
//         State:request.body.State,
//         Pincode:request.body.Pincode,
//         PhoneNo:request.body.PhoneNo,
//         MobileNo:request.body.MobileNo,
//         PhysicalDisabilityIfAny:request.body.PhysicalDisabilityIfAny,
//         MaritalStatus:request.body.MaritalStatus,
//         EducationStatus:request.body.EducationStatus,
//         BirthSign:request.body.BirthSign,
    
//     });
//     productModel.updateOne(id,person,function(err,res){
//         // console.log(res);
         
//    if (err) {
//      response.statusCode = 500;
//      response.send(err);
//    }
//    response.send({ status: 200, data: res });
//  }); 
    
 
//  }

}

