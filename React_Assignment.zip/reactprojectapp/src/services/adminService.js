class AdminService {
  saveNewUserData(userData) {
    console.log("in admin service");
    let promise = fetch("http://localhost:4070/api/userData", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(userData)
    });
    return promise;
  }

  getAllList() {
    let promise = fetch("http://localhost:4070/api/getUserDetails", {
      method: "GET"
    });
    return promise;
  }
  savePersonInfoData(info) {
    console.log("in service");
      let promise = fetch("http://localhost:4070/api/savePersoninfo", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(info)
        
      });
      return promise;
    }
}

export default AdminService;
