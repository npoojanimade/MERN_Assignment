class LoginService {
    postData(logindata) {
      console.log("in service");
        let promise = fetch("http://localhost:4070/api/signin", {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify(logindata)
          
        });
        return promise;
      }
}
 
export default LoginService ;