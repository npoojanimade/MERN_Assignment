import "./../../css/design.css";
import React, { Component } from "react";
import AdminService from "../../services/adminService";

class UpdateUserAccessData extends Component {
  constructor(props) {
    let userid = sessionStorage.getItem("userid");
    super(props);
    this.state = {
      PersonalUniqueId: 0,
      FirstName: "",
      MiddleName: "",
      LastName: "",
      Gender: "",
      DOB: "",
      Age: 0,
      Address: "",
      City: "",
      State: "",
      Pincode: 0,
      PhoneNo: 0,
      MobileNo: 0,
      PhysicalDisability: "",
      MaritalStatus: "",
      EducationalStatus: "",
      BirthSign: "",
      UserId:0
    };
    this.serv = new AdminService()
  }
  
  putValue = e => {
    this.setState({ [e.target.name]: e.target.value });
  };

  savePersnInfo = e => {
    let info ={
      PersonalUniqueId: this.state.PersonalUniqueId,
      FirstName: this.state.FirstName,
      MiddleName: this.state.MiddleName,
      LastName: this.state.LastName,
      Gender: this.state.Gender,
      DOB: this.state.DOB,
      Age: this.state.Age,
      Address: this.state.Address,
      City: this.state.City,
      State: this.state.State,
      Pincode: this.state.Pincode,
      PhoneNo: this.state.PhoneNo,
      MobileNo: this.state.MobileNo,
      PhysicalDisability: this.state.PhysicalDisability,
      MaritalStatus: this.state.MaritalStatus,
      EducationalStatus: this.state.EducationalStatus,
      BirthSign: this.state.BirthSign,
      UserId:this.userid
    }
    this.serv
      .savePersonInfoData(info)
      .then(res => res.json())
      .then(resp => resp.data)
      .catch(error => console.log(error.status));
  }
 
  render() {
   
  
  //  console.log("userId is +++++++++"+userid)
    // let x = document.getElementById("updateButton").disabled;
    return (
      <div id="login">
        <h3 className="text-center text-white pt-5">User Registration Form</h3>
        <div className="form">
          <div
            id="login-row"
            className="row justify-content-center align-items-center"
          >
            <div id="login-column" className="col-md-6">
              <div id="login-box" className="col-md-12">
                <form id="login-form" className="form" method="post">
                  <h3 className="text-center text-info">User Information</h3>
                  <div className="col-sm-12">
                    <div className="row">
                      <div className="col-sm-12 form-group">
                        <label className="text-info">PersonalUniqueId</label>
                        <input type="text" className="form-control"  onChange={this.putValue.bind(this)} required />
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-sm-4 form-group">
                        <label className="text-info">First Name</label>
                        <input type="text" className="form-control"  onChange={this.putValue.bind(this)} required />
                      </div>
                      <div className="col-sm-4 form-group">
                        <label className="text-info">Middle Name</label> 
                        <input type="text" className="form-control"  onChange={this.putValue.bind(this)} required />
                      </div>
                      <div className="col-sm-4 form-group">
                        <label className="text-info">Last Name</label>
                        <input type="text" className="form-control"  onChange={this.putValue.bind(this)} required />
                      </div>
                    </div>

                    <div className="form-group">
                      <label className="control-label col-sm-3 text-info">
                        Gender
                      </label>
                      <div className="col-sm-6">
                        <div className="row">
                          <div className="col-sm-4">
                            <label className="text-info">
                              <input
                                type="radio"
                                id="femaleRadio"
                                value="Female"
                                onChange={this.putValue.bind(this)}
                              />
                              Female
                            </label>
                          </div>
                          <div className="col-sm-4">
                            <label className="text-info">
                              <input type="radio" id="maleRadio" value="Male"  onChange={this.putValue.bind(this)} />
                              Male
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="row">
                      <div className="col-sm-6 form-group">
                        <label className="text-info">DOB</label>
                        <input
                          type="date"
                          className="form-control text-info"
                          onChange={this.putValue.bind(this)}
                          required
                        />
                      </div>
                      <div className="col-sm-6 form-group">
                        <label className="text-info">Age</label>
                        <input type="text" className="form-control"  onChange={this.putValue.bind(this)} required />
                      </div>
                    </div>

                    <div className="form-group">
                      <label className="text-info">Address</label>
                      <textarea rows="3" className="form-control"  onChange={this.putValue.bind(this)} required />
                    </div>
                    <div className="row">
                      <div className="col-sm-4 form-group">
                        <label className="text-info">City</label>
                        <input type="text" className="form-control"  onChange={this.putValue.bind(this)} required />
                      </div>
                      <div className="col-sm-4 form-group">
                        <label className="text-info">State</label>
                        <input type="text" className="form-control"  onChange={this.putValue.bind(this)} required />
                      </div>
                      <div className="col-sm-4 form-group">
                        <label className="text-info">PinCode</label>
                        <input type="text" className="form-control"  onChange={this.putValue.bind(this)} required />
                      </div>
                    </div>

                    <div className="row">
                      <div className="col-sm-6 form-group">
                        <label className="text-info">PhoneNo</label>
                        <input type="text" className="form-control"  onChange={this.putValue.bind(this)} required />
                      </div>
                      <div className="col-sm-6 form-group">
                        <label className="text-info">Mobile</label>
                        <input type="text" className="form-control"  onChange={this.putValue.bind(this)} required />
                      </div>
                    </div>

                    <div className="row">
                      <div className="col-sm-6 form-group">
                        <label className="text-info">PhysicalDisability</label>
                        <select className="form-control text-info"  onChange={this.putValue.bind(this)}>
                          <option>yes</option>
                          <option>no</option>
                        </select>
                      </div>
                      <div className="col-sm-6 form-group">
                        <label className="text-info">Marital Status</label>
                        <select className="form-control text-info"  onChange={this.putValue.bind(this)}>
                          <option>Married</option>
                          <option>UnMarried</option>
                          <option>Divorced</option>
                          <option>Widow</option>
                          <option>Widowed</option>
                        </select>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-sm-6 form-group">
                        <label className="text-info">Educational Status</label>
                        <select className="form-control text-info"  onChange={this.putValue.bind(this)}>
                          <option>Masters</option>
                          <option>Graduate</option>
                          <option>UnderGraduate</option>
                          <option>SSC</option>
                          <option>HSC</option>
                          <option>phD</option>
                          <option>illiterate</option>
                        </select>
                      </div>
                      <div className="col-sm-6 form-group">
                        <label className="text-info">Birth Sign</label>
                        <input type="text" className="form-control"  onChange={this.putValue.bind(this)} required />
                      </div>
                      <div className="row">
                        <div className="col-sm-4">
                          <input
                            type="button"
                            value="Save"
                            onClick={this.savePersnInfo.bind(this)}
                            className="btn btn-info btn-md"
                          />
                        </div>
                        <div className="col-sm-4">
                          <input
                            type="button"
                            value="Update"
                            id="updateButton"
                            className="btn btn-info btn-md" disabled
                          />
                        </div>
                        <div className="col-sm-4">
                          <input
                            type="button"
                            value="Cancel"
                            className="btn btn-danger"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default UpdateUserAccessData;
