import React, { Component } from "react";
import "./../../css/design.css";
import LoginService from "./../../services/loginservice";

class LoginPage extends Component {
  constructor(props) {
    super(props);
    this.state = {
      UserName: "",
      Password: ""
    };
    this.serv = new LoginService();
  }

  putValue = e => {
    this.setState({ [e.target.name]: e.target.value });
  };

  checkAuth(e) {
    //  const h = this.props.history;

    // h.push('/accessUserInfo');
    let logindata = {
      UserName: this.state.UserName,
      Password: this.state.Password
    };
    // console.log("UserName is ==="+UserName);

    this.serv
      .postData(logindata)
      .then(res => res.json())
      .then(resp => {
        if (resp.authenticated) {
          console.log("in if");
          sessionStorage.setItem("token", resp.token);
          sessionStorage.setItem("roleid", resp.data);
          const h = this.props.history;
          console.log("resp.data===" + resp.data);
          if (resp.data === 1) {
            // if admin
            h.push("/adminHome");
          } else {
            if (resp.data === 2) {
              // if user
              h.push("/accessUserInfo");
            } else {
              if (resp.data === 3) {
                // if operator
                h.push("/operatorHome");
              }
            }
          }
        }else{
          alert("Login Failed")
        }
      })
      .catch(error => console.log(error.status));
  }

  render() {
    return (
      <div id="login">
        <h3 className="text-center text-white pt-5">Login</h3>
        <div className="container">
          <div
            id="login-row"
            className="row justify-content-center align-items-center"
          >
            <div id="login-column" className="col-md-6">
              <div id="login-box" className="col-md-12">
                <form id="login-form" className="form">
                  <h3 className="text-center text-info">Login</h3>
                  <div className="form-group">
                    <label className="text-info">Username:</label>
                    <input
                      type="text"
                      name="UserName"
                      onChange={this.putValue.bind(this)}
                      className="form-control"
                    />
                  </div>
                  <div className="form-group">
                    <label className="text-info">Password:</label>
                    <input
                      type="password"
                      name="Password"
                      onChange={this.putValue.bind(this)}
                      className="form-control"
                    />
                  </div>
                  <div className="form-group">
                    <input
                      type="button"
                      value="Submit"
                      onClick={this.checkAuth.bind(this)}
                      className="btn btn-info btn-md"
                    />
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default LoginPage;
